'use strict';

/**
 * @ngdoc function
 * @name WindYao.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the WindYao
 */
angular.module('WindYao')
  .controller('ExpCtrl', function ($scope) {
    $scope.data = [];
  });
