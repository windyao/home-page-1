'use strict';

/**
 * @ngdoc function
 * @name WindYao.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the WindYao
 */
angular.module('WindYao')
  .controller('ToDoListCtrl', function ($scope) {
    $scope.data = [];
  });
